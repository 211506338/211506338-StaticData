#pragma once
#include"cocos2d.h"
/*���*/
class FishLayer :public cocos2d::Layer
{
public:
	FishLayer();
	~FishLayer();
	bool init();
};

