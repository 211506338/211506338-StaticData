#pragma once
#include"cocos2d.h"
/*�˵���*/
class MenuLayer :public cocos2d::Layer
{
public:
	MenuLayer();
	~MenuLayer();
	bool init();
};

